/* console.log("Hello word");

var a = 1;
var b = 2;
var r = a+b;
console.log("Resultado de la suma: " + r);

var n1 = 10;
var n2 = 2;
var R = n1*n2;
console.log("Resultado de la multiplicacion: " + R);

var nr = 1244;
var resr = Math.sqrt(nr);
console.log("Resultado de la raiz: " + resr);
var resent = Math.floor(resr);
console.log("Resultado de la raiz cuadrada sin decimales: " + resent); */



