console.log("entramos");

var items =document.getElementsByClassName("items");

var cantidad = items.length;

console.log("cantidad de listas " + cantidad); 

var div = document.createElement("div");

div;

div.innerText = "Aprendiendo JavaScript";

var divuno = document.getElementById("uno");

divuno.appendChild(div);

var lista = document.getElementById("lista");

var hijo = document.createElement("li");
hijo. innerText = "li nuevo";
lista.appendChild(hijo);

document.getElementById("miParrafo").style.color = "red";
document.getElementById("lista").style.color = "green";

var padre = document.getElementById("padre");
var p = document.createElement("p");
var list = document.createElement("ul");
var li1 = document.createElement("li");
var li2 = document.createElement("li");
var li3 = document.createElement("li");
li1.innerText = "item1";
li2.innerText = "item2";
li3.innerText = "item3";
p.innerText= "Había una vez un hombre que estaba emergido en el oscuro y callado bosque, en donde los sonidos se podían interpretar como dulces gritos. él iba muy sereno hasta que escucho el llanto de una mujer, asustado busca encontrar explicación al grito. Él corría tan rápido que incluso las sombras de los pinos  parecían personas obsrvandolo. Cuando de repente, observa a un pequeño hombresillo cuyo nombre era desesperación. ";
padre.appendChild(p);
padre.appendChild(list);
list.appendChild(li1);
list.appendChild(li2);
list.appendChild(li3);
p.style.color = "red";
list.style.color = "green";
var fondo = document.getElementById("padre");
fondo.style.background = "blue";



